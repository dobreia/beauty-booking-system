import express from "express";
import pool from "../db.js";

const router = express.Router();

// GET /api/services
router.get("/", async (req, res) => {
    try {
        const result = await pool.query("SELECT * FROM services ORDER BY id");
        res.json(result.rows);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: "DB error" });
    }
});

export default router;
