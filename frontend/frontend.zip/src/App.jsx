import { useState } from 'react'
import { BrowserRouter, Routes, Route } from 'react-router-dom'
import Navbar from './components/Navbar'
import Footer from './components/Footer'
import HomePage from './pages/HomePage'
import BookingPage from './pages/BookingPage'
import ServicePage from './pages/admin/ServicePage'
import UserPage from './pages/admin/UserPage'

function App() {

  return (
    <>
      <BrowserRouter>
        <Navbar />
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/booking" element={<BookingPage />} />
          {/* Admin oldalak */}
          <Route path="/admin/services" element={<ServicePage />} />
          <Route path="/admin/users" element={<UserPage />} />
        </Routes>
        <Footer />
      </BrowserRouter>


    </>
  )
}

export default App
