export default function Navbar() {
    return (
        <nav className="navbar">
            <h2>Szépségszalon</h2>
            <ul>
                <li><a href="/">Főoldal</a></li>
                <li><a href="/booking">Foglalás</a></li>
                <li><a href="/login">Bejelentkezés</a></li>
                <li><a href="/admin">Admin</a></li>
                <li><a href="/admin/services">Szolgáltatások</a></li>   
                <li><a href="/admin/users">Felhasználók</a></li>
            </ul>
        </nav>
    );
}
