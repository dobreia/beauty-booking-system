import { useEffect, useState } from "react";

export default function ServicesPage() {
    const [services, setServices] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        fetch("/api/services")
            .then((res) => res.json())
            .then(setServices)
            .catch((err) => setError(err))
            .finally(() => setLoading(false));
    }, []);

    if (loading) return <p>Betöltés...</p>;
    if (error) return <p>Hiba történt: {error.message}</p>;

    return (
        <div className="container mt-4">
            <h2>Szolgáltatások</h2>
            <table className="table table-striped mt-3">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Név</th>
                        <th>Időtartam (perc)</th>
                        <th>Ár (Ft)</th>
                        <th>Aktív</th>
                    </tr>
                </thead>
                <tbody>
                    {services.map((s) => (
                        <tr key={s.id}>
                            <td>{s.id}</td>
                            <td>{s.name}</td>
                            <td>{s.duration_minutes}</td>
                            <td>{(s.price_cents / 100).toLocaleString()} Ft</td>
                            <td>{s.active ? "Yes" : "No"}</td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
}
