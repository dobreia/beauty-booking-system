import { useEffect, useState } from "react";

export default function UserPage() {
    const [users, setUsers] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        fetch("/api/users")
            .then((res) => res.json())
            .then(setUsers)
            .catch((err) => setError(err))
            .finally(() => setLoading(false));
    }, []);

    if (loading) return <p>Betöltés...</p>;
    if (error) return <p>Hiba történt: {error.message}</p>;

    return (
        <div className="container mt-4">
            <h2>Felhasználók</h2>
            <table className="table table-striped mt-3">
                <thead>
                    <tr>
                        <th>Név</th>
                        <th>Email</th>
                        <th>Szerepkör</th>
                    </tr>
                </thead>
                <tbody>
                    {users.map((u) => (
                        <tr key={u.id}>
                            <td>{u.name}</td>
                            <td>{u.email}</td>
                            <td>{u.role}</td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
}
